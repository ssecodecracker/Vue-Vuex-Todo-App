const URL = 'https://jsonplaceholder.typicode.com/todos/';
//Store using Vuex
const store = new Vuex.Store({
  state: {
    todos: [],
    loading: true
  },
  getters: {
    todos: state => state.todos,
  },
  mutations: {
    updatetodos(state, todos) {
      state.todos = todos
    },
    changeLoadingState(state, loading) {
      state.loading = loading
    }
  },
  actions: {
    loadData({ commit }) {
      axios.get(URL).then((response) => {
        response.data.forEach((val, index) => {
          val.order = index;
        });
        commit('updatetodos', response.data)
        commit('changeLoadingState', false)
      })
    },
    updateTodo({ commit }, payload) {
      commit('updatetodos', payload.todos)
    }
  }
})

//Vue app init
var app = new Vue({
  store,
  el: '#todoApp',
  data() {
    const componentInstance = this;
    return {
      options: {
        onDragend(event) {
          //update order on drag not achieved
          // componentInstance.reorderOnDrag(event.oldIndex, event.newIndex);
        },
      },
      //Object representing selected TODO
      selectedTodo: {}
    }
  },
  computed: Vuex.mapState(['todos', 'loading']),
  created() {
    this.$store.dispatch('loadData');
  },
  methods: {
    //Show details on clicking on TODO list item
    showTodo(todo) {
      this.selectedTodo = todo;
    },

    reorderOnDrag(oldIndex, newIndex) {
      // move the item in the underlying array
      this.$store.getters.todos.splice(newIndex, 0, this.list.splice(oldIndex, 1)[0]);
      // update order property based on position in array
      this.$store.getters.todos.forEach(function (item, index) {
        item.order = index;
      });
    },

    sortTodo(event, sortBy) {
      debugger
      document.querySelector(".btn.active").classList.remove("active");
      event.target.classList.add("active");

      //Get TODO list from Store
      let todoList = this.$store.getters.todos;

      //Array containing sorted/ordered TODO
      let sortedTodoList = [];

      //Sort by id
      if (sortBy == "id") {
        sortedTodoList = todoList.sort(function (a, b) {
          return a["id"] - b["id"]
        })
      }

      //Sort by order
      if (sortBy == "order") {
        sortedTodoList = todoList.sort(function (a, b) {
          return a["order"] - b["order"]
        })
      }

      //Add random sort to native array object
      Array.prototype.randomSort = function () {
        let newTodo = [];
        this.forEach((val, index) => {
          let randomIndex = Math.floor(Math.random() * this.length);
          while (newTodo.includes(this[randomIndex])) {
            randomIndex = Math.floor(Math.random() * this.length)
          }
          newTodo[index] = this[randomIndex];
        })
        return newTodo
      }

      //Sort random
      if (sortBy == "random") {
        sortedTodoList = todoList.randomSort();
      }

      //Update sorted value in store
      this.$store.dispatch('updateTodo', { 'todos': sortedTodoList });
      console.log(sortedTodoList);

      //Update UI after sort
      app.$forceUpdate();

    }
  }
});

//Drag implementation
Vue.use(VueDraggable.default);